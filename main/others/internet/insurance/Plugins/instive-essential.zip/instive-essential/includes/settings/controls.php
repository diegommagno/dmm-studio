<?php 

function instive_settings_api_init() {

    add_settings_section(
       'instive_service_setting_section',
       'Insurance service settings',
       null,
       'writing'
   );
 
   add_settings_field(
       'instive_setting_slug',
       'Service Slug',
       'instive_service_slug_setting_callback_function',
       'writing',
       'instive_service_setting_section'
   );

   add_settings_field(
    'instive_singular_name',
    'Service singular name',
    'instive_service_singular_setting_callback_function',
    'writing',
    'instive_service_setting_section'
   );
   
   add_settings_field(
    'instive_plural_name',
    'Service plural name',
    'instive_service_plural_setting_callback_function',
    'writing',
    'instive_service_setting_section'
   );

    register_setting( 'writing', 'instive_setting_slug' );
    register_setting( 'writing', 'instive_singular_name' );
    register_setting( 'writing', 'instive_plural_name' );
} 

add_action( 'admin_init', 'instive_settings_api_init' );


function instive_service_plural_setting_callback_function() {
    $name = get_option('instive_plural_name');
  
    echo '<input name="instive_plural_name" id="instive_plural_name" type="text" value="'.$name.'" />';
}

function instive_service_singular_setting_callback_function() {
    $sname = get_option('instive_singular_name');

    echo '<input name="instive_singular_name" id="instive_singular_name" type="text" value="'.$sname.'" />';
}

function instive_service_slug_setting_callback_function() {
    $slug = get_option('instive_setting_slug');
    echo '<input name="instive_setting_slug" id="instive_setting_slug" type="text" value="'.$slug.'" />';
}

// service category settings


function instive_service_category_settings_api_init() {

    add_settings_section(
       'instive_service_cat_setting_section',
       'Service Category settings',
       null,
       'writing'
   );
 
   add_settings_field(
       'instive_cat_setting_slug',
       'Category slug',
       'instive_service_cat_slug_setting_callback_function',
       'writing',
       'instive_service_cat_setting_section'
   );

   add_settings_field(
    'instive_cat_singular_name',
    'Category name',
    'instive_service_cat_singular_setting_callback_function',
    'writing',
    'instive_service_cat_setting_section'
   );

    // tag

    add_settings_field(
        'instive_tag_setting_slug',
        'Tags slug',
        'instive_service_tag_slug_setting_callback_function',
        'writing',
        'instive_service_cat_setting_section'
    );
 
    add_settings_field(
     'instive_tag_singular_name',
     'Tags name',
     'instive_service_tag_singular_setting_callback_function',
     'writing',
     'instive_service_cat_setting_section'
    );
     

    register_setting( 'writing', 'instive_cat_setting_slug' );
    register_setting( 'writing', 'instive_cat_singular_name' );
    // tag
    register_setting( 'writing', 'instive_tag_setting_slug' );
    register_setting( 'writing', 'instive_tag_singular_name' );

} 

add_action( 'admin_init', 'instive_service_category_settings_api_init' );

function instive_service_cat_singular_setting_callback_function() {
    $sname = get_option('instive_cat_singular_name');
   
    echo '<input name="instive_cat_singular_name" id="instive_cat_singular_name" type="text" value="'.$sname.'" />';
}

function instive_service_cat_slug_setting_callback_function() {
    $slug = get_option('instive_cat_setting_slug');
    echo '<input name="instive_cat_setting_slug" id="instive_cat_setting_slug" type="text" value="'.$slug.'" />';
}

//tag


function instive_service_tag_singular_setting_callback_function() {
    $sname = get_option('instive_tag_singular_name');

    echo '<input name="instive_tag_singular_name" id="instive_tag_singular_name" type="text" value="'.$sname.'" />';
}

function instive_service_tag_slug_setting_callback_function() {
    $slug = get_option('instive_tag_setting_slug');
    echo '<input name="instive_tag_setting_slug" id="instive_tag_setting_slug" type="text" value="'.$slug.'" />';
}






