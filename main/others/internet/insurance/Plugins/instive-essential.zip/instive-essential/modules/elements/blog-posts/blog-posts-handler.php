<?php
namespace ElementsKit;

class Instive_Widget_Blog_Posts_Handler extends Core\Handler_Widget{

    static function get_name() {
        return 'elementskit-blog-posts';
    }

    static function get_title() {
        return esc_html__( 'Instive Blog Posts', 'instive-essential' );
    }

    static function get_icon() {
        return ' ekit-widget-icon eicon-posts-grid';
    }

    static function get_categories() {
        return [ 'instive-elements' ];
    }

    static function get_dir() {
        return \ElementsKit::widget_dir() . 'blog-posts/';
    }

    static function get_url() {
        return \ElementsKit::widget_url() . 'blog-posts/';
    }

}